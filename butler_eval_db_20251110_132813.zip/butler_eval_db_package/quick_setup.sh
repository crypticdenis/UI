#!/bin/bash

# Quick Setup Script for Butler Eval Database
# Run this after installing PostgreSQL

echo "🚀 Butler Eval Database Quick Setup"
echo "===================================="
echo ""

# Check if PostgreSQL is installed
if ! command -v psql &> /dev/null; then
    echo "❌ PostgreSQL not found. Please install PostgreSQL 14+ first."
    exit 1
fi

echo "✅ PostgreSQL found"
echo ""

# Database name
DB_NAME="butler_eval"

# Check if database exists
if psql -U postgres -lqt | cut -d \| -f 1 | grep -qw $DB_NAME; then
    echo "⚠️  Database '$DB_NAME' already exists."
    read -p "Do you want to drop and recreate it? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        echo "🗑️  Dropping existing database..."
        dropdb -U postgres $DB_NAME
    else
        echo "❌ Setup cancelled."
        exit 0
    fi
fi

# Create database
echo "📦 Creating database '$DB_NAME'..."
createdb -U postgres $DB_NAME

if [ $? -ne 0 ]; then
    echo "❌ Failed to create database. Try running:"
    echo "   createdb butler_eval"
    exit 1
fi

echo "✅ Database created"
echo ""

# Load schema
echo "📊 Loading schema..."
psql -U postgres -d $DB_NAME -f schema.sql > /dev/null 2>&1

if [ $? -ne 0 ]; then
    echo "❌ Failed to load schema. Try running:"
    echo "   psql -U postgres -d butler_eval -f schema.sql"
    exit 1
fi

echo "✅ Schema loaded"
echo ""

# Verify
echo "🔍 Verifying setup..."
TABLE_COUNT=$(psql -U postgres -d $DB_NAME -tAc "SELECT COUNT(*) FROM pg_tables WHERE schemaname='public';")

if [ "$TABLE_COUNT" -eq "6" ]; then
    echo "✅ All 6 tables created successfully!"
    echo ""
    echo "📋 Tables:"
    psql -U postgres -d $DB_NAME -c "\dt"
    echo ""
    echo "🎉 Setup complete!"
    echo ""
    echo "📖 Next steps:"
    echo "   1. Read DATABASE_STRUCTURE.md"
    echo "   2. Configure backend connection"
    echo "   3. Start backend server"
else
    echo "⚠️  Expected 6 tables, found $TABLE_COUNT"
    echo "   Check schema.sql file"
fi
